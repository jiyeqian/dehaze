% Access to 172.20.53.144 is needed!

input_image='image\flag.jpg';
output_image='result\dehaze_flag.jpg';
dehaze(input_image, output_image);
